package scs.util.utilitization; 
import scs.util.tools.DataFormats;
import scs.util.tools.DateFormats;  

/**
 * 记录EMU的线程类
 * @author yanan
 *
 */
public class UtilityController extends Thread{
	//private final int SLEEP_TIME=3000;
 
	public UtilityController(){}
	
	DataFormats dataFormats=DataFormats.getInstance();
	DateFormats dateFormats=DateFormats.getInstance();
	@Override
	public void run(){
	 
	}
 

}
